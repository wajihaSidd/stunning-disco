public class Node {
    WeatherRecord data;  // The weather data
    Node next;           // Reference to the next node

    // Constructor to create a new node
    public Node(WeatherRecord data) {
        this.data = data;
        this.next = null;
    }
}
