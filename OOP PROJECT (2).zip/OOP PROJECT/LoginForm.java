import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    private JButton ExitButton;

    public LoginForm() {
        // Set up the login form GUI
        setTitle("Login Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));


        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);

        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Perform login logic
                boolean loginSuccess = loginUser(username, password);
                if (loginSuccess) {
                    JOptionPane.showMessageDialog(null, "Login Successful");
                    clearFields();
                    DeleteFields();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.");
                }
            }
        });

        panel.add(loginButton, ExitButton);

        add(panel);
        add(panel);
    }

    private boolean loginUser(String username, String password) {
        // Perform your login logic here
        // You can check against a database or a predefined list of users
        // For simplicity, we'll check against a hardcoded username and password

        // Hardcoded username and password for demonstration purposes
        String validUsername = "admin";
        String validPassword = "password";

        return username.equals(validUsername) && password.equals(validPassword);
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
    }
    private void DeleteFields(){
        System.exit(0);
    }

}
