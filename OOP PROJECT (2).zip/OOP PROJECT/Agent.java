

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Agent {

    private String name;
    private String password;
    private String contact_no;
    private String Cninc_no;
    private String company_name;
    private String experience;
    private String commission;

    public Agent() {
        this.name = null;
        this.commission = null;
        this.company_name = null;
        this.Cninc_no = null;
        this.experience = null;
        this.contact_no = null;
        this.password = null;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getCninc_no() {
        return Cninc_no;
    }

    public void setCninc_no(String cninc_no) {
        Cninc_no = cninc_no;
    }

    public String getcompany_name() {
        return company_name;
    }

    public void setcompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }


    public Agent(String name, String contact_no, String cninc_no, String company_name, String experience, String commission, String password) {
        this.name = name;
        this.contact_no = contact_no;
        this.password = password;
        Cninc_no = cninc_no;
        this.company_name = company_name;
        this.experience = experience;
        this.commission = commission;
    }


    public void RegisterAgent(String name, String pass, String contact_no, String cninc_no, String company_name, String experience, String commission) {

        try {
            FileWriter fw = new FileWriter("Agents.txt", true);
            fw.append(name + "\n");
            fw.append(pass + "\n");
            fw.append(contact_no + "\n");
            fw.append(cninc_no + "\n");
            fw.append(company_name + "\n");
            fw.append(cninc_no + "\n");
            fw.append(experience + " \n");
            fw.append(commission+"\n");
            fw.append("\n");
            fw.close();


        } catch (Exception e) {
            System.out.println(e);
        }


    }


    Boolean login_agent(String name, String password) {

        File file = new File("Agents.txt");

        try {
            Scanner scanner = new Scanner(file);

            //now read the file line by line...
            int lineNum = 0;
            while (scanner.hasNextLine()) {
                String f_name = scanner.nextLine();
                lineNum++;
                if (f_name.equals(name)) {
                    String f_pass = scanner.nextLine();
                    if (password.equals(f_pass)) {
                        return true;
                    } else
                        return false;

                }


            }
        } catch (FileNotFoundException e) {
            //handle this
        }
        return false;

    }

    public void allocate_plot(String buyer_name,String agent_name) throws IOException {

        String allocate_name=buyer_name;


        String filePath = "Properties.txt";
        Scanner sc = new Scanner(new File(filePath));
        //instantiating the StringBuffer class
        StringBuffer buffer = new StringBuffer();
        //Reading lines of the file and appending them to StringBuffer
        while (sc.hasNextLine()) {
            buffer.append(sc.nextLine()+System.lineSeparator());
        }
        String fileContents = buffer.toString();
        //closing the Scanner object
        sc.close();
        String oldLine = String.valueOf(agent_name);
        String newLine = String.valueOf(allocate_name);
        //Replacing the old line with new line
        fileContents = fileContents.replaceAll(oldLine, newLine);
        //instantiating the FileWriter class
        FileWriter writer = new FileWriter(filePath);
        writer.append(fileContents);
        writer.flush();
        //writer.close();





    }

    public void see_plots(String name)
    {

        String agent_name=name;



        File file = new File("Properties.txt");
        Boolean b=true;
        try {
            Scanner s = new Scanner(file);

            //now read the file line by line...
            int lineNum = 0       ;



            while (s.hasNextLine()) {
                String line = s.nextLine();
                if(line.equals(agent_name))
                {
                    b=false;
                    System.out.println("Plot Location : "+s.nextLine());
                    System.out.println("Plot Condition: "+s.nextLine());
                    System.out.println("Plot Size in SqFoot : "+s.nextLine());
                    System.out.println("Plot Price is : "+s.nextLine());
                    line=s.nextLine();



                }

            }


        }

        catch(FileNotFoundException e) {
            //handle this
        }

        if(b)
        {
            System.out.println("No Plot Found ");
        }





    }

    public void contact_seller(Property p,String seller_name)
    {
        try {
            FileWriter fw = new FileWriter("Properties.txt", true);
            fw.append(seller_name+"\n");
            fw.append(p.getPlot_location() + "\n");
            fw.append(p.getPlot_condition() + "\n");
            fw.append(p.getPlot_size() + " \n");
            fw.append(p.getPlot_price() + "\n");
            fw.append("\n");
            fw.close();


        } catch (Exception e) {

            System.out.println(e);
        }








    }

    public void view_agents() {
        File file = new File("Agents.txt");

        try {
            Scanner s = new Scanner(file);

            //now read the file line by line...
            int lineNum = 0       ;
            System.out.println("Agents Whom Which You Can Contact For Dealrships are :");

            while (s.hasNextLine()) {
                String line = s.nextLine();

                lineNum++;
                if(lineNum==1)
                {
                    System.out.println("Agent Name is : "+line);

                }
                if(lineNum==5)
                {
                    System.out.println("Agent Company is : "+line);
                    System.out.println();
                }

                if(line.isEmpty() && s.hasNextLine())
                {
                    System.out.println("Agent Name is : "+s.nextLine());

                    int i=3;
                    while(i!=0)
                    {
                        String l=s.nextLine();
                        i--;
                    }

                    System.out.println("Agent Company Name is : "+s.nextLine());
                    System.out.println();

                }








            }


        }

        catch(FileNotFoundException e) {
            //handle this
        }









    }
    public void Buy_Plot(String loc)
    {


    }





}

