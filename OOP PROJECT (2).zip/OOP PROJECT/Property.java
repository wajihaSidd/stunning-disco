
public class Property {

    private String plot_location;
    private String plot_size;
    private String plot_price;
    private String plot_condition;
    public Property()
    {
        plot_location=null;
        plot_size = null;
        plot_price=null;
        plot_condition=null;
    }
    public Property(String plot_location, String plot_size, String plot_price, String plot_condition) {

        this.plot_location = plot_location;
        this.plot_size = plot_size;
        this.plot_price = plot_price;
        this.plot_condition = plot_condition;
    }

    public String getPlot_location() {
        return plot_location;
    }

    public void setPlot_location(String plot_location) {
        this.plot_location = plot_location;
    }

    public String getPlot_size() {
        return plot_size;
    }

    public void setPlot_size(String plot_size) {
        this.plot_size = plot_size;
    }

    public String getPlot_price() {
        return plot_price;
    }

    public void setPlot_price(String plot_price) {
        this.plot_price = plot_price;
    }

    public String getPlot_condition() {
        return plot_condition;
    }

    public void setPlot_condition(String plot_condition) {
        this.plot_condition = plot_condition;
    }





}

