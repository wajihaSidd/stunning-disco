//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//public class RealEstateMainPage extends JFrame {
//    private JTextField usernameField;
//    private JPasswordField passwordField;
//    private JButton loginButton;
//
//    private JButton ExitButton;
//
//    public RealEstateMainPage() {
//        // Set up the main page GUI
//        setTitle("Real Estate Management System");
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setSize(400, 300);
//        setLocationRelativeTo(null);
//
//        JPanel panel = new JPanel(new GridBagLayout());
//        GridBagConstraints constraints = new GridBagConstraints();
//        constraints.insets = new Insets(10, 10, 10, 10);
//
//        JLabel titleLabel = new JLabel("Welcome to Real Estate Management System");
//        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
//
//        JLabel usernameLabel = new JLabel("Username:");
//        usernameField = new JTextField(20);
//
//        JLabel passwordLabel = new JLabel("Password:");
//        passwordField = new JPasswordField(20);
//
//        loginButton = new JButton("Login");
//        loginButton.setPreferredSize(new Dimension(80, 30));
//        loginButton.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                String username = usernameField.getText();
//                char[] password = passwordField.getPassword();
//
//                // Validate the username and password
//                if (username.equals("admin") && String.valueOf(password).equals("password")) {
//                    JOptionPane.showMessageDialog(null, "Login Successful");
//                    // Proceed to the next screen or functionality
//                } else {
//                    JOptionPane.showMessageDialog(null, "Invalid credentials");
//                }
//            }
//        });
//
//
//
//
//        constraints.gridx = 0;
//        constraints.gridy = 0;
//        constraints.gridwidth = 2;
//        constraints.anchor = GridBagConstraints.CENTER;
//        panel.add(titleLabel, constraints);
//
//        constraints.gridx = 0;
//        constraints.gridy = 1;
//        constraints.gridwidth = 5;
//        constraints.anchor = GridBagConstraints.LINE_END;
//        panel.add(usernameLabel, constraints);
//
//        constraints.gridx = 1;
//        constraints.gridy = 1;
//        constraints.anchor = GridBagConstraints.LINE_START;
//        panel.add(usernameField, constraints);
//
//        constraints.gridx = 0;
//        constraints.gridy = 2;
//        constraints.anchor = GridBagConstraints.LINE_END;
//        panel.add(passwordLabel, constraints);
//
//        constraints.gridx = 1;
//        constraints.gridy = 2;
//        constraints.anchor = GridBagConstraints.LINE_START;
//        panel.add(passwordField, constraints);
//
//        constraints.gridx = 0;
//        constraints.gridy = 3;
//        constraints.anchor = GridBagConstraints.CENTER;
//        constraints.insets = new Insets(20, 10, 10, 10);
//        constraints.gridwidth = 2;
//        panel.add(loginButton, constraints);
//        panel.add(ExitButton, constraints);
//
//
//        add(panel);
//    }
//}
//





















import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//public class RealEstateMainPage extends JFrame {
//    private JTextField usernameField;
//    private JPasswordField passwordField;
//    private JButton loginButton;
//    private JButton exitButton;
//
//    public RealEstateMainPage() {
//        setTitle("Real Estate Management System");
//        setSize(400, 300);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLocationRelativeTo(null);
//        setLayout(new BorderLayout());
//
//        JPanel loginPanel = new JPanel();
//        loginPanel.setLayout(new GridLayout(3, 2, 10, 10));
//        //----------------------------------------------
////         Set up the main page GUI
//        setTitle("Real Estate Management System");
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setSize(400, 300);
//        setLocationRelativeTo(null);
//
//        JPanel panel = new JPanel(new GridBagLayout());
//        GridBagConstraints constraints = new GridBagConstraints();
//        constraints.insets = new Insets(10, 10, 10, 10);
//        JLabel welcomeLabel = new JLabel("Welcome to our Real Estate");
//        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
//        panel.add(welcomeLabel);
//
//
////        -----------------------------------------------------
//
//
//        JLabel usernameLabel = new JLabel("Username:");
//        usernameField = new JTextField();
//        JLabel passwordLabel = new JLabel("Password:");
//        passwordField = new JPasswordField();
////        System.exit(0);
//        loginPanel.add(usernameLabel);
//        loginPanel.add(usernameField);
//        loginPanel.add(passwordLabel);
//        loginPanel.add(passwordField);
//
//        JPanel buttonPanel = new JPanel();
//        loginButton = new JButton("Login");
//        exitButton = new JButton("Exit");
//
//        buttonPanel.add(loginButton);
//        buttonPanel.add(exitButton);
//
//        add(loginPanel, BorderLayout.CENTER);
//        add(buttonPanel, BorderLayout.SOUTH);
//
////        System.exit(0);
//
//
////        ----------------------------------------------------
////        JLabel usernameLabel = new JLabel("Username:");
////        usernameField = new JTextField(20);
////
////        JLabel passwordLabel = new JLabel("Password:");
////        passwordField = new JPasswordField(20);
////
////        loginButton = new JButton("Login");
////        loginButton.setPreferredSize(new Dimension(80, 30));
////        loginButton.addActionListener(new ActionListener() {
////            public void actionPerformed(ActionEvent e) {
////                String username = usernameField.getText();
////                char[] password = passwordField.getPassword();
////
////                // Validate the username and password
////                if (username.equals("admin") && String.valueOf(password).equals("password")) {
////                    JOptionPane.showMessageDialog(null, "Login Successful");
////                    // Proceed to the next screen or functionality
////                } else {
////                    JOptionPane.showMessageDialog(null, "Invalid credentials");
////                }
////            }
////        });
//        //----------------------------------------------------------------
//
//        loginButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                String username = usernameField.getText();
//                String password = new String(passwordField.getPassword());
//
//                // Add your login logic here
//
//                // Example: Display login credentials
//                JOptionPane.showMessageDialog(RealEstateMainPage.this, "Login successful" );
//            }
//        });
//
//        exitButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                System.exit(0);
//            }
//        });
//    }
//
//}
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RealEstateMainPage extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton exitButton;

    public RealEstateMainPage() {
        setTitle("Real Estate Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridLayout(3, 2, 10, 10));

        // Set up the welcome label with design
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(10, 10, 10, 10);

        JLabel welcomeLabel = new JLabel("Welcome to Real Estate");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.BLUE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(welcomeLabel);

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        loginPanel.add(usernameLabel);
        loginPanel.add(usernameField);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);

        JPanel buttonPanel = new JPanel();
        loginButton = new JButton("Login");
        exitButton = new JButton("Exit");

        buttonPanel.add(loginButton);
        buttonPanel.add(exitButton);

        add(panel, BorderLayout.NORTH);
        add(loginPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (username.equals("admin") && password.equals("admin")) {
                    JOptionPane.showMessageDialog(RealEstateMainPage.this, "Login Successful");
                } else {
                    JOptionPane.showMessageDialog(RealEstateMainPage.this, "User not found");
                }
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

    }

    public static void main(String[] args) {
        RealEstateMainPage mainPage = new RealEstateMainPage();
        mainPage.setVisible(true);
    }
}

