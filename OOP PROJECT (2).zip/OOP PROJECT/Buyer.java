

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Buyer extends Agent {

    private String name;


    private  String password;


    private String contact_no;
    private String Cninc_no;


    public Buyer() {
        this.name = null;

        this.Cninc_no = null;

        this.contact_no = null;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getCninc_no() {
        return Cninc_no;
    }

    public void setCninc_no(String cninc_no) {
        Cninc_no = cninc_no;


    }


    public Buyer(String name, String contact_no, String cninc_no,String password) {
        this.name = name;
        this.password=password;
        this.contact_no = contact_no;
        Cninc_no = cninc_no;

    }
    Boolean login_buyer(String name,String password)
    {

        File file = new File("Buyers.txt");

        try {
            Scanner scanner = new Scanner(file);

            //now read the file line by line...
            int lineNum = 0;
            while (scanner.hasNextLine()) {
                String f_name = scanner.nextLine();
                lineNum++;
                if(f_name.equals(name))
                {
                    String f_pass=scanner.nextLine();
                    if(password.equals(f_pass))
                    {
                        return  true;
                    }
                    else
                        return false;

                }



            }
        } catch(FileNotFoundException e) {
            //handle this
        }
        return false;

    }



    public void RegisterBuyer(String name, String password, String contact_no, String cninc_no) {

        try {
            FileWriter fw = new FileWriter("Buyers.txt", true);
            fw.append(name + "\n");
            fw.append(password+"\n");

            fw.append(contact_no + "\n");
            fw.append(cninc_no + "\n");

            fw.append("\n");
            fw.close();


        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void view_agents() {
        super.view_agents();
    }

    @Override
    public void see_plots(String name) {
        super.see_plots(name);
    }

    @Override
    public void allocate_plot(String buyer_name,String agent_name) throws IOException {

        super.allocate_plot(buyer_name,agent_name);
    }
}

