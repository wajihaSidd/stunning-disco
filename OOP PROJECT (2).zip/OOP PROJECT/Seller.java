
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class Seller  extends  Agent{

    private String name;

    private String contact_no;
    private String Cninc_no;


    public Seller() {
        this.name = null;

        this.Cninc_no = null;

        this.contact_no = null;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getCninc_no() {
        return Cninc_no;
    }

    public void setCninc_no(String cninc_no) {
        Cninc_no = cninc_no;


    }


    public Seller(String name, String contact_no, String cninc_no, String company_name, String experience, String commission) {
        this.name = name;
        this.contact_no = contact_no;
        Cninc_no = cninc_no;

    }


    public void RegisterSeller(String name, String password,String contact_no, String cninc_no) {

        try {
            FileWriter fw = new FileWriter("Sellers.txt", true);
            fw.append(name + "\n");
            fw.append(password+ "\n");
            fw.append(contact_no + "\n");
            fw.append(cninc_no + "\n");

            fw.append("\n");
            fw.close();
            System.out.println("Record Added");

        } catch (Exception e) {
            System.out.println(e);
        }


    }
    Boolean login_seller(String name,String password)
    {

        File file = new File("Sellers.txt");

        try {
            Scanner scanner = new Scanner(file);

            //now read the file line by line...
            int lineNum = 0;
            while (scanner.hasNextLine()) {
                String f_name = scanner.nextLine();
                lineNum++;
                if(f_name.equals(name))
                {
                    String f_pass=scanner.nextLine();
                    if(password.equals(f_pass))
                    {
                        return  true;
                    }
                    else
                        return false;

                }



            }
        } catch(FileNotFoundException e) {
            //handle this
        }
        return false;

    }

    @Override
    public void view_agents() {
        super.view_agents();
    }

    public void contactagent(String agent_name)
    {
        Scanner sc=new Scanner(System.in);
        Property p=new Property();
        System.out.print("Enter THe Plot Location :");
        p.setPlot_location(sc.nextLine());
        System.out.print("Enter THe Plot Conition  (New /Old) :");
        p.setPlot_condition(sc.nextLine());
        System.out.print("Enter THe Plot Size in Sqr Foots:  ");
        p.setPlot_size(sc.nextLine());
        System.out.print("Enter Your Offered Price:");
        p.setPlot_price(sc.nextLine());


        contact_seller(p,agent_name);

    }





}

