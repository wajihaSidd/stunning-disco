


import javax.swing.*;
import java.io.IOException;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) throws IOException {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                RealEstateMainPage mainPage = new RealEstateMainPage();
                mainPage.setVisible(true);
            }
        });


//        SwingUtilities.invokeLater(new Runnable() {
//            public void run() {
//
//            }
//        });


        String login_name = null;
        String login_password = null;

        int option = 0;
        while (true) {

            System.out.println("Welcome To Real Estate Management System \n");
            System.out.println("Note : You Must Register Before Login ");
            System.out.println("1 - Login As Agent ");
            System.out.println("2- Login As Owner/Seller:  ");
            System.out.println("3- Login As Buyer : ");
            System.out.println("4- Dont Have An account / Create Account");
            System.out.println("5 - Exit The System");
            Scanner sc = new Scanner(System.in);
            option = sc.nextInt();
            if (option == 5) {
                break;
            } else if (option == 1) {
                //Agent

                System.out.println("Enter Your  Name ");
                Scanner input = new Scanner(System.in);
                login_name = input.nextLine();
                System.out.println("Enter Your Password ");
                login_password = input.nextLine();

                Agent agent = new Agent();
                if (agent.login_agent(login_name, login_password)) {

                    System.out.println("Login Sucesful");

                    System.out.println("Do You Want To See Your Plots Given By Seller  (yes/no)");
                    Scanner c = new Scanner(System.in);

                    String i = c.nextLine();
                    if (i.equals("yes")) {

                        System.out.println("The Plots:  \n");
                        agent.see_plots(login_name);

                        System.out.println();
                    }
                } else {
                    System.out.println("Agent Not Found");
                }
            } else if (option == 2) {
                //Owner


                Scanner input = new Scanner(System.in);
                System.out.println("Enter Your  Name ");

                login_name = input.nextLine();
                System.out.println("Enter Your Password ");
                login_password = input.nextLine();


                Seller seller = new Seller();
                if (seller.login_seller(login_name, login_password)) {

                    System.out.println("Login Suceessful");

                    System.out.println();
                    seller.view_agents();
                    System.out.println("Enter The Agent Name :");
                    Scanner agent_input = new Scanner(System.in);
                    String ag_name = agent_input.nextLine();

                    seller.contactagent(ag_name);

                } else {
                    System.out.println("Seller Not Found");

                }
            } else if (option == 3) {
                //Buyer
                Scanner input = new Scanner(System.in);
                System.out.println("Enter Your  Name ");

                login_name = input.nextLine();
                System.out.println("Enter Your Password ");
                login_password = input.nextLine();

                Buyer buyer = new Buyer();
                if (buyer.login_buyer(login_name, login_password)) {
                    System.out.println("Login Sucessful");
                    System.out.println();
                    System.out.println();

                    System.out.println("1 - Do You Want Buy A Plot");
                    System.out.println("2- See Your Plots On Your Name");
                    int input_c = 0;
                    Scanner choice = new Scanner(System.in);
                    input_c = choice.nextInt();
                    if (input_c == 1) {


                        buyer.view_agents();
                        Scanner agent_input = new Scanner(System.in);
                        System.out.println("Enter THe Agent Name Whom You Want To Contact : ");
                        String agent_name = agent_input.nextLine();
                        buyer.see_plots(agent_name);
                        System.out.println("Do you want to Buy Any Plot ? ( yes /no) ");
                        String in = agent_input.nextLine();
                        if (in.toLowerCase().equals("yes")) {

                            System.out.println("Enter The Plot Location Which You want To Buy");

                            String plot_loc = agent_input.nextLine();
                            System.out.println("Enter Your Account No For Payment  : ");
                            String account_no = agent_input.nextLine();

                            buyer.allocate_plot(login_name, agent_name);
                            System.out.println("Transaction has benn Sucesful");

                        }

                    } else if (input_c == 2) {

                        buyer.see_plots(login_name);


                    }


                } else {
                    System.out.println("Buyer Not Found ..");
                }


            } else if (option == 4) {
                //Register

                int register = 0;


                while (true) {

                    System.out.println("1- Register As Agent ");
                    System.out.println("2- Register As Buyer : ");

                    System.out.println("3- Register As Owner/Seller:  ");
                    System.out.println("4 - Return To Login Screen");
                    register = sc.nextInt();

                    if (register == 1) {
                        Scanner input = new Scanner(System.in);
                        String name;
                        String contact_no;
                        String cninc_no;
                        String company_name;
                        String experience;
                        String commission;
                        String password;

                        System.out.println("Enter your Name : ");
                        name = input.nextLine();

                        System.out.println("Enter your password :");
                        password = input.nextLine();

                        System.out.println("Enter your Contact_No : ");
                        contact_no = input.nextLine();

                        System.out.println("Enter your Cninc_no : ");
                        cninc_no = input.nextLine();

                        System.out.println("Enter your Real_Estate_Company: ");
                        company_name = input.nextLine();

                        System.out.println("Enter your Expericene : ");
                        experience = input.nextLine();

                        System.out.println("How Much Average Commision You Take On A Plot : ");
                        commission = input.nextLine();


                        Agent agent = new Agent();
                        agent.RegisterAgent(name, password, contact_no, cninc_no, company_name, experience, commission);


                    } else if (register == 2) {

                        Scanner input = new Scanner(System.in);
                        //Buyer
                        String name;
                        String contact_no;
                        String cninc_no;
                        String password;
                        System.out.println("Enter your Name : ");
                        name = input.nextLine();


                        System.out.println("Enter your password :");
                        password = input.nextLine();


                        System.out.println("Enter your Contact_No : ");
                        contact_no = input.nextLine();
                        System.out.println("Enter your Cninc_no : ");
                        cninc_no = input.nextLine();


                        Buyer Buyer = new Buyer();
                        Buyer.RegisterBuyer(name, password, contact_no, cninc_no);


                    } else if (register == 3) {
                        Scanner input = new Scanner(System.in);
                        String name;
                        String contact_no;
                        String cninc_no;
                        String password;

                        System.out.println("Enter your Name : ");
                        name = input.nextLine();


                        System.out.println("Enter your password :");
                        password = input.nextLine();

                        System.out.println("Enter your Contact_No : ");
                        contact_no = input.nextLine();
                        System.out.println("Enter your Cninc_no : ");
                        cninc_no = input.nextLine();


                        Seller Seller = new Seller();
                        Seller.RegisterSeller
                                (name, password, contact_no, cninc_no);


                    } else if (register == 4) {
                        break;
                    }
                }
            }


        }


    }
}















//import javax.swing.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.io.IOException;
//
//public class Main {
//
//    public static void main(String[] args) throws IOException {
//        String login_name = null;
//        String login_password = null;
//
//        int option = 0;
//        while (true) {
//            System.out.println("Welcome To Real Estate Management System\n");
//            System.out.println("Note: You Must Register Before Login");
//            System.out.println("1 - Login As Agent");
//            System.out.println("2 - Login As Owner/Seller");
//            System.out.println("3 - Login As Buyer");
//            System.out.println("4 - Don't Have An Account / Create Account");
//            System.out.println("5 - Exit The System");
//
//            option = JOptionPane.showOptionDialog(null, "Choose an option", "Real Estate Management System", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, new String[]{"Login As Agent", "Login As Owner/Seller", "Login As Buyer", "Don't Have An Account / Create Account", "Exit The System"}, null);
//
//            if (option == 4) {
//                JTextField nameField = new JTextField();
//                JPasswordField passwordField = new JPasswordField();
//
//                Object[] fields = {
//                        "Name:", nameField,
//                        "Password:", passwordField
//                };
//
//                int input = JOptionPane.showConfirmDialog(null, fields, "Account Registration", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
//
//                if (input == JOptionPane.OK_OPTION) {
//                    login_name = nameField.getText();
//                    login_password = new String(passwordField.getPassword());
//
//                    // Register logic here
//                    // ...
//
//                    JOptionPane.showMessageDialog(null, "Account Registered Successfully");
//                }
//            } else if (option == 0) {
//                JTextField nameField = new JTextField();
//                JPasswordField passwordField = new JPasswordField();
//
//                Object[] fields = {
//                        "Name:", nameField,
//                        "Password:", passwordField
//                };
//
//                int input = JOptionPane.showConfirmDialog(null, fields, "Agent Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
//
//                if (input == JOptionPane.OK_OPTION) {
//                    login_name = nameField.getText();
//                    login_password = new String(passwordField.getPassword());
//
//                    Agent agent = new Agent();
//                    if (agent.login_agent(login_name, login_password)) {
//                        JOptionPane.showMessageDialog(null, "Login Successful");
//
//                        // Rest of the code for agent login
//                        // ...
//                    } else {
//                        JOptionPane.showMessageDialog(null, "Agent Not Found");
//                    }
//                }
//            } else if (option == 1) {
//                JTextField nameField = new JTextField();
//                JPasswordField passwordField = new JPasswordField();
//
//                Object[] fields = {
//                        "Name:", nameField,
//                        "Password:", passwordField
//                };
//
//                int input = JOptionPane.showConfirmDialog(null, fields, "Seller Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
//
//                if (input == JOptionPane.OK_OPTION) {
//                    login_name = nameField.getText();
//                    login_password = new String(passwordField.getPassword());
//
//                    Seller seller = new Seller();
//                    if (seller.login_seller(login_name, login_password)) {
//                        JOptionPane.showMessageDialog(null, "Login Successful");
//
//                        // Rest of the code for seller login
//                        // ...
//                    } else {
//                        JOptionPane.showMessageDialog(null, "Seller Not Found");
//                    }
//                }
//            } else if (option == 2) {
//                JTextField nameField = new JTextField();
//                JPasswordField passwordField = new JPasswordField();
//
//                Object[] fields = {
//                        "Name:", nameField,
//                        "Password:", passwordField
//                };
//
//                int input = JOptionPane.showConfirmDialog(null, fields, "Buyer Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
//
//                if (input == JOptionPane.OK_OPTION) {
//                    login_name = nameField.getText();
//                    login_password = new String(passwordField.getPassword());
//
//                    Buyer buyer = new Buyer();
//                    if (buyer.login_buyer(login_name, login_password)) {
//                        JOptionPane.showMessageDialog(null, "Login Successful");
//
//                        // Rest of the code for buyer login
//                        // ...
//                    } else {
//                        JOptionPane.showMessageDialog(null, "Buyer Not Found");
//                    }
//                }
//            } else if (option == 3) {
//                JTextField nameField = new JTextField();
//                JPasswordField passwordField = new JPasswordField();
//
//                Object[] fields = {
//                        "Name:", nameField,
//                        "Password:", passwordField
//                };
//
//                int input = JOptionPane.showConfirmDialog(null, fields, "Account Registration", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
//
//                if (input == JOptionPane.OK_OPTION) {
//                    login_name = nameField.getText();
//                    login_password = new String(passwordField.getPassword());
//
//                    // Register logic here
//                    // ...
//
//                    JOptionPane.showMessageDialog(null, "Account Registered Successfully");
//                }
//            }
//        }
//    }
//}
//
//
//
